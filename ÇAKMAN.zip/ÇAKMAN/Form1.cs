using System.Diagnostics;
using System.Net;

namespace ÇAKMAN
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }




        private void button1_Click(object sender, EventArgs e)
        {

            {
                string hedefLink = "https://docs.google.com/document/d/1IeD-SFT88NthruXu_XUgCmW8i173Abmo/edit"; // Senin belirlediğin bağlantı

                Process.Start(new ProcessStartInfo
                {
                    FileName = hedefLink,
                    UseShellExecute = true // Bu kısmı yazmazsan çalışmaz!
                });
            }
        }






        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
                string hedefLink = "https://docs.google.com/document/d/10f5UHAArAeVpW0vbos0mwqDIpkTwnrK6/edit"; // Senin belirlediğin bağlantı

                Process.Start(new ProcessStartInfo
                {
                    FileName = hedefLink,
                    UseShellExecute = true // Bu kısmı yazmazsan çalışmaz!
                });
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form2 YENı = new Form2();
            YENı.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
